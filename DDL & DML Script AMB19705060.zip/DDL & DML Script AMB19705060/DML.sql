-- dml statements

-- procedure for query 4.1 (find location vechile and drive at any given day and time.
-- A DELIMITER is used to tell the mysql client to treat the statements and stored procedures as an entire statement.  
DELIMITER $$  
CREATE PROCEDURE track_vehicle() -- creates procedure to track vehicle for a specific data type
BEGIN 
                SELECT * FROM AssignVehicleGps,gps, shift,drivers,parcels -- selects from the following tables listed
                Where gps.TrackingGpsID = AssignVehicleGps.TrackingGpsID -- references entity table
AND 
AssignVehicleGps.shiftNo = shift.shiftNo 
AND 
gps.v_reg= '105' -- uses specific data field(vehicle reg:105) to search for related entity fields
AND 
shift.shiftDate= '220521'
AND
Parcels.delivery_Date= '220521'
AND
Parcels.delivery_Time= '920';
END $$ 
DELIMITER ; 




 
 CALL track_vehicle();-- calling the value allows the user to see output of procedure
-- track_vehicle would output the location of vehicle and its driver from given date and time and any nexessary fields involved.

-- nested query for locating vehicle reg 62
SELECT *
FROM delivery
WHERE location IN (SELECT location
                   FROM gps
                   WHERE v_reg IN ("62"))
		   LIMIT 1 -- only limits to one data to be shown than multiple data from fields.

-- SELF JOIN FOR REFERENCING VEHICLE WITH TRACKINGGPSID.
-- gps.v_reg = x.TrackingGpsID

-- create a character for each attribute
SELECT gps.TrackingGpsID, gps.location AS navigation, gps.v_reg AS vehicle

FROM gps INNER JOIN gps AS vehicle
ON gps.TrackingGpsID = vehicle.location

-- RIGHT JOIN FOR REFERENCING VEHICLE WITH TRACKINGGPSID.


-- create a character for each attribute
SELECT gps.TrackingGpsID, gps.location AS navigation, gps.v_reg AS vehicle

FROM gps RIGHT JOIN gps AS vehicle
ON gps.TrackingGpsID = vehicle.location

-- LEFT JOIN FOR REFERENCING VEHICLE WITH TRACKINGGPSID.


-- create a character for each attribute
SELECT gps.TrackingGpsID, gps.location AS navigation, gps.v_reg AS vehicle

FROM gps LEFT JOIN gps AS vehicle
ON gps.TrackingGpsID = vehicle.location

DELIMITER $$  
CREATE PROCEDURE findvehicle() -- procedure to find location of another vehicle from a given date/time
BEGIN 
                SELECT * FROM AssignVehicleGps,gps, shift,drivers,parcels
                Where gps.TrackingGpsID = AssignVehicleGps.TrackingGpsID 
AND 
AssignVehicleGps.shiftNo = shift.shiftNo 
AND 
gps.v_reg= '80' 
AND 
shift.shiftDate= '240521'
AND
Parcels.delivery_Date= '240521'
AND
Parcels.delivery_Time= '1230';
END $$ 
DELIMITER ; 
 CALL findvehicle();

DELIMITER $$  
CREATE PROCEDURE specific_driver() 
BEGIN 
                SELECT * FROM AssignDriverDelivered, drivers, parcelsDelivered 
                Where drivers.driver_id = AssignDriverDelivered.driver_id  
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Jodie' ;
END $$ 
DELIMITER ; 
 CALL specific_driver(); 

 
-- basic query statements to locate vehicle and its driver referencing from relevant tables and its relational entities
Select  parcelsDelivered.date,parcelsDelivered.deliveredParcels, drivers.driver_name 
from AssignDriverDelivered, drivers, parcelsDelivered 
 
Where drivers.driver_id = AssignDriverDelivered.driver_id 
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Jodie' 

DELIMITER $$  
CREATE PROCEDURE specific_driveranddate() 
BEGIN 
                SELECT * FROM AssignDriverDelivered, drivers, parcelsDelivered 
                Where drivers.driver_id = AssignDriverDelivered.driver_id  
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Jodie' 
AND 
parcelsDelivered.date = 200521; 

END $$ 
DELIMITER ; 
 CALL specific_driveranddate(); 

 
Select  parcelsDelivered.date,parcelsDelivered.deliveredParcels, drivers.driver_name 
from AssignDriverDelivered, drivers, parcelsDelivered 
 
Where drivers.driver_id = AssignDriverDelivered.driver_id 
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Jodie' 
AND 
parcelsDelivered.date = 200521 
 
 
Select  parcelsDelivered.date,parcelsDelivered.deliveredParcels, drivers.driver_name 
from AssignDriverDelivered, drivers, parcelsDelivered 
 
Where drivers.driver_id = AssignDriverDelivered.driver_id 
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Jodie' 
AND 
parcelsDelivered.date = 230521 

DELIMITER $$  
CREATE PROCEDURE specific_driveranddate2() 
BEGIN 
                SELECT * FROM AssignDriverDelivered, drivers, parcelsDelivered 
                Where drivers.driver_id = AssignDriverDelivered.driver_id  
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Saleem' 
AND 
parcelsDelivered.date = 260521; 

END $$ 
DELIMITER ; 
 CALL specific_driveranddate2(); 

 
Select  parcelsDelivered.date,parcelsDelivered.deliveredParcels, drivers.driver_name 
from AssignDriverDelivered, drivers, parcelsDelivered 
 
Where drivers.driver_id = AssignDriverDelivered.driver_id 
AND 
AssignDriverDelivered.referenceNo = parcelsDelivered.referenceNo 
AND 
drivers.driver_name = 'Saleem' 
AND 
parcelsDelivered.date = 260521 
 
 
Select  driver_name 
from drivers 
 
DELIMITER $$  
CREATE PROCEDURE am_drivers() 
BEGIN 
                SELECT * FROM AssignDriverShift, drivers, shiftType 
                Where drivers.driver_id = AssignDriverShift.driver_id 
AND 
AssignDriverShift.shiftNo = shiftType.shiftNo 
AND 
shiftType.AmorPm= 'am'; 
END $$ 
DELIMITER ; 
 CALL am_drivers() ;

-- nested query for specifying drivers woking morning shifts.
                   
SELECT *
FROM shift
WHERE driver_id IN (SELECT driver_id
                   FROM shifttype
                   WHERE AmorPm IN ("am"))
		   LIMIT 1 -- only limits to one data to be shown than multiple data from fields.

Select  driver_name, shiftType.AmorPm 
from AssignDriverShift, drivers, shiftType 
 
Where drivers.driver_id = AssignDriverShift.driver_id 
AND 
AssignDriverShift.shiftNo = shiftType.shiftNo 
AND 
shiftType.AmorPm= 'am' 
 
 
 

